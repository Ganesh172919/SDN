# SELF X SDN control with adaptive episodic memory

SELF-X tests whether a network controller can reuse past states, actions, outcomes and reflections to manage repeated congestion. It includes a portable simulation, real Gemini and free OpenRouter adapters, a local dashboard and a separate Linux Mininet/Ryu adapter.

[Project purpose](docs/PROJECT_GUIDE.md) | [Architecture and flow](docs/ARCHITECTURE.md) | [Current benchmarks](docs/BENCHMARKS_V3.md) | [Original protocol](docs/EXPERIMENTS.md) | [Submission files](output/submission/)

All changes and outputs stay in selfx. Submitted network results come from a documented fluid simulation. API calls are real and separately audited. Physical-network performance and guaranteed memory improvement are not claimed.

## Run on this computer

```powershell
cd C:\Users\RAVIPRAKASH\SDN\SDN\selfx
.\run.ps1 test
.\run.ps1 dashboard
```

Open **http://127.0.0.1:8765**. The launcher requires and uses this folder's isolated .venv. The .env file stores credentials separately. It never installs into global Python. If script execution is blocked, use `powershell -ExecutionPolicy Bypass -File .\run.ps1 dashboard` for that process.

On a new Windows computer with Python 3.10+, run `setup.ps1`, then `run.ps1 experiment` and `run.ps1 dashboard`.

For Linux/macOS portable use:

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements-dev.txt
python -m pytest tests eval/tests -q
python -m eval.run_simulation
python app.py
```

## API and experiments

```powershell
.\run.ps1 experiment     # offline 5 seeds x 120 windows x 5 controllers including A4
.\run.ps1 probe          # discovery plus one live decision per provider
.\run.ps1 gemini         # paced three-seed integration pilot
.\run.ps1 openrouter     # small free-router integration pilot
.\run.ps1 free-models    # one check for every discovered zero-price :free model
```

Keys belong in `.env` using `.env.example`, or in environment variables. Existing environment values take precedence. Never put keys into browser code or documents. `.env` is ignored by Git and excluded from the source submission bundle.

The requested model endpoint is `gemini-3.5-flash-lite`. OpenRouter supports `openrouter/free` and explicit `:free` models, while paid model names are blocked. Availability and quotas are external prerequisites; every checked model receives a success or failure record. Requests use timeouts, pacing and a bounded circuit breaker. A1/A2 failures become visible no-op actions; A4 uses an explicitly labeled validated heuristic fallback.

```bash
python -m eval.run_simulation --provider offline --cycles 120 --seeds 1729 1730 1731 1732 1733 --out-dir output/experiments/custom
python -m eval.run_simulation --provider openrouter --model openrouter/free --cycles 12 --seeds 1729 --out-dir output/experiments/custom_free
```

Output paths outside selfx are rejected. Reruns reset their condition/seed memories; use a new output directory to retain older evidence.

## Evidence and submission

`output/experiments/` holds CSV metrics, JSONL traces, traffic hashes, memory and summaries. `output/provider_check.json` and `free_model_checks.json` document provider access. `output/submission/` contains the editable DOCX, report PDF, editable PPTX and slide PDF. The documents are built from saved results.

A0 is a static primary route; B1 is a greedy feasible least-loaded route. A1 has no episode memory. A2 retrieves similar earlier states. Offline A1/A2 are deterministic policies, while API A1/A2 call the named provider. These experiments are reported separately. Memory is evaluated rather than assumed to help.

The dashboard binds to 127.0.0.1 and serves an explicit file allowlist. Offline replay writes only to `output/experiments/dashboard`. API experiments run from the CLI so credentials stay with Python.

## Separate Linux testbed

`topo.py` requires Linux root access, Open vSwitch, Mininet and iperf3. It remains a linear four-switch/eight-host topology. Install system dependencies in a dedicated Linux testbed, then run:

```bash
ryu-manager --ofp-tcp-listen-port 6653 ryu.app.ofctl_rest ryu.app.simple_switch_13
sudo -E python3 -m eval.run_ablation --duration 600 --results-dir output/testbed_results
```

Use a separate Ryu-compatible Python environment if necessary. Windows testing does not validate this external installation. The linear topology offers no alternate path, so rerouting is blocked unless a validated egress map is supplied. Metered flows preserve their observed forwarding output. Original switch-port throughput sums transmissions across hops; it is not endpoint goodput. Drop counters are a proxy, not full end-to-end loss. Real deployment requires endpoint instrumentation and sustained Linux validation before performance claims.

## Navigation

```text
app.py + web/             local dashboard
agent/                    schemas providers embedding memory graph reward prompts metrics
eval/simulator.py         finite-buffer two-path model
eval/run_simulation.py    portable evaluation
eval/run_ablation.py      Linux testbed evaluation
safety.py                 deterministic action bounds
scripts/                  provider checks artifact builds verification
tests/ + eval/tests/      regression suite
docs/                     purpose architecture and experimental protocol
output/                   evidence and submission files
```

## Historical v2 benchmark reference

The previous 57,600-window, six-scenario/eight-controller study remains in `output/benchmarks/v2`. Its historical protocol is in [BENCHMARKS.md](docs/BENCHMARKS.md). Current run commands use v3 and current submission files contain the v3 results.

## Current revision 3

See [the full benchmark guide](docs/BENCHMARKS_V3.md), [all 15 PNG/SVG graphs](output/benchmarks/v3/figures/) and [synthetic NetFlow-style traffic](output/benchmarks/v3/traffic/simulated_netflow.csv). The current primary suite has 86,400 windows. The separate post-hoc memory sensitivity diagnostic has 19,200 windows. A4 is included in normal experiments and dashboard replay.

Run `.\run.ps1 all` for tests, the complete offline project and primary benchmarks. Run `.\run.ps1 latency` for the live Gemini three-mode comparison. The measured hybrid mean cycle changed from 8.295 s to 2.096 s (74.7% reduction), with 2/24 five-second misses. All provider work and local reuse have distinct provenance. A4 matches guard-only H1 in the primary suite; the targeted diagnostic demonstrates a loss/reward benefit with increased modeled delay.

For a normal fast API demo with only A0 and A4:

```powershell
.\.venv\Scripts\python.exe -m eval.run_simulation --provider gemini --conditions A0 A4 --cycles 12 --seeds 1792 --out-dir output/experiments/custom_fast
```

The existing `.env` is configured and ignored. `.venv` is the isolated Python environment. Final editable reports, slides, PDFs and the verified ZIP are in [output/submission](output/submission/).
