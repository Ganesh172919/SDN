# Benchmark navigation

- v2: preserved prior six-scenario/eight-controller study.
- v3: current eight-scenario/nine-controller study, separate memory sensitivity, fresh Gemini pilot, preserved initial prompt diagnostic, all free-model checks, synthetic NetFlow-style CSV, and a dedicated figures folder with 15 PNG/SVG pairs.

The primary suite and post-hoc memory diagnostic remain separate. See ../../docs/BENCHMARKS_V3.md for commands and limitations.
