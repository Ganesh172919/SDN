param([ValidateSet('dashboard','experiment','test','probe','gemini','openrouter','free-models','benchmark','latency','all')][string]$Mode='dashboard',[int]$Port=8765)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath $PSScriptRoot
$localPython=Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
$bundledPython=Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
if (-not (Test-Path -LiteralPath $localPython)) { throw 'Run .\setup.ps1 first to create the project-local .venv' }
$taskPython=$localPython
Remove-Item Env:PYTHONPATH -ErrorAction SilentlyContinue
switch($Mode) {
    'dashboard' { & $taskPython app.py --port $Port }
    'experiment' { & $taskPython -m eval.run_simulation }
    'test' { & $taskPython -m pytest tests eval/tests -q }
    'probe' { & $taskPython -m scripts.probe_providers }
    'gemini' { & $taskPython -m eval.run_simulation --provider gemini --cycles 24 --seeds 1729 1730 1731 --out-dir output/experiments/gemini_paced }
    'openrouter' { & $taskPython -m eval.run_simulation --provider openrouter --cycles 12 --seeds 1729 --out-dir output/experiments/openrouter }
    'free-models' { & $taskPython -m scripts.sweep_free_models }
    'benchmark' { & $taskPython -m eval.run_adaptive_benchmarks }
    'latency' { & $taskPython -m eval.run_latency_benchmark }
    'all' { & $taskPython -m scripts.validate_runtime }
}
exit $LASTEXITCODE
