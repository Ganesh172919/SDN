# SELF X architecture and project navigation

[Start here](../README.md) | [Project goal](PROJECT_GUIDE.md) | [Experiment design](EXPERIMENTS.md) | [Submission files](../output/submission/)

## Project goal

Test whether a single network-control agent can make better decisions by retrieving its own previous state, action, measured outcome and reflection. The controller selects `reroute`, `rate_limit` or `no_op`. Its decisions pass through deterministic checks before reaching the network adapter.

The original folder implemented reward-ranked few-shot memory, not embeddings. The extension adds a transparent numeric state embedding with cosine retrieval. This is in-context adaptation; neither model weights nor embedding weights are trained.

## Complete execution flow

```mermaid
flowchart TD
    U[Local dashboard or CLI] --> T[Generate one seeded traffic trace]
    T --> C[Reset each controller and seed]
    C --> O[Observe current demand and path queues]
    O --> E[Normalize state vector]
    E --> R[Retrieve earlier similar episodes for A2]
    R --> D[Offline policy or real provider request]
    D --> J[Parse JSON and validate DecisionOutput]
    J --> S[Check switch flow egress capacity and rate floor]
    S -->|allowed| A[Apply one-window action]
    S -->|veto or API failure| N[Apply no_op and record reason]
    A --> M[Measure delivered volume loss and modeled delay]
    N --> M
    M --> W[Compare with same-window no-op counterfactual]
    W --> F[Generate reflection]
    F --> B[Store bounded A2 episode memory]
    B --> L[Append raw metrics decision trace and provider audit]
    L --> O
    L --> P[Aggregate paired seed means and uncertainty]
    P --> V[Dashboard charts editable report and presentation]
```

## Simulated topology

```mermaid
flowchart LR
    H[Logical source hosts] --> S1[s1 ingress]
    S1 -->|port 2 primary 10 Mbps| S2[s2]
    S1 -->|port 3 alternate 10 Mbps| S3[s3]
    S2 --> S4[s4 egress]
    S3 --> S4
    S4 --> D[Logical destination hosts]
```

This is a two-bottleneck fluid abstraction with logical endpoints, not eight instantiated hosts or packet-level switches. Each bottleneck has a 0.5 Mbit buffer and 8 ms propagation delay. Background traffic loads both paths; an elephant flow starts on the primary each window. Rerouting changes that flow's path; a meter caps only that flow. Each action expires after five simulated seconds. The next window starts a new flow; queues persist within a condition and seed.

The separate Linux topology in `topo.py` remains linear. It cannot demonstrate an alternate route. Its agent rejects rerouting unless a tested loop-free egress mapping is supplied through `AgentDeps.allowed_reroute_ports_fn`. The diamond has not been deployed to Mininet here.

## Embedding and retrieval

`agent/embedding.py` constructs `[primary_background/10, alternate_background/10, elephant/10, queue_primary/0.5, queue_alternate/0.5, primary_offered/10, 0.1]` and normalizes it to unit length. Cosine similarity ranks earlier episodes. Four examples enter each simulation prompt. The original testbed uses normalized latency, switch-port transmission rate and loss features instead.

`agent/memory.py` writes JSON atomically, retains at most 30 episodes and prunes lowest rewards. Retrieval ranks retained episodes by similarity. Reward pruning can lose informative failures; similar states may need different actions. A1 receives no stored episodes. Each condition and seed starts with empty memory.

## Modules and entry points

| File | Responsibility |
| --- | --- |
| `app.py`, `web/` | Loopback dashboard with explicit static download and API routes |
| `eval/simulator.py` | Traffic, queues, action validation and fluid equations |
| `eval/run_simulation.py` | Portable A0/B1/A1/A2 runs, provenance, CSV/JSONL and seed comparisons |
| `agent/providers.py` | Gemini/free OpenRouter REST, pacing and sanitized audit |
| `agent/schemas.py` | Typed decisions and reflections |
| `agent/embedding.py`, `agent/memory.py` | State vectors and bounded episode retrieval |
| `agent/reward.py`, `safety.py` | Reward deltas and deterministic action bounds |
| `agent/graph.py` | Original LangGraph pipeline for Ryu |
| `ryu_client.py`, `topo.py`, `traffic_gen.py` | Separate Linux testbed adapter |
| `eval/result_schema.py`, `result_writer.py` | Validated testbed bundles |
| `scripts/`, `tests/`, `eval/tests/` | Artifact builds, checks and regression tests |

## API and filesystem boundary

The browser never receives keys. `.env` is loaded only by Python, ignored by Git and excluded from the submission bundle. Only enumerated assets, sanitized results and final artifacts are downloadable. API calls carry synthetic state, not captured user network traffic. OpenRouter accepts its free router or `:free` model IDs and blocks paid names. A catalog sweep checks every visible zero-price `:free` model once and records successes and failures.

Timeouts, quota errors and invalid responses produce visible `fallback_no_op` decisions. Failed reflections use deterministic metric sentences with separate provenance. Two consecutive failures open the provider instance's circuit breaker. Request gaps can be configured with `GEMINI_REQUEST_GAP_SEC` and `OPENROUTER_REQUEST_GAP_SEC`; quotas remain account-dependent.

## Data lineage

## Enhanced benchmark branch

See [benchmark design and graph navigation](BENCHMARKS.md). `eval/run_benchmarks.py` expands the workload into six scenarios and evaluates eight controllers on identical per-seed traces. `agent/guarded_memory.py` adds bounded balanced retention and feasibility-aware retrieval; H1 is the guard-only ablation. `scripts/benchmark_visuals.py` converts the saved rows into eight PNG/SVG chart pairs and a PDF atlas. The dashboard serves only enumerated benchmark figures and sanitized aggregate results.

```mermaid
flowchart LR
    W[Six seeded scenarios] --> P[Eight paired controllers]
    P --> H[Common feasibility gate]
    H --> M[Measured fluid outcomes]
    M --> C[CSV and traffic hashes]
    C --> B[Paired seed bootstrap]
    B --> V[Dashboard and graph atlas]
    B --> D[Editable report and slides]
```

The local runtime is `.venv`; `.env` remains a separate credentials file. `run.ps1 all` verifies tests, the portable run and expanded benchmarks using that interpreter.

```text
output/experiments/<run>/traffic_<seed>.json   fixed demand and SHA256
                      /metrics.csv           one measured window per row
                      /trace.jsonl           state decision outcome and reflection
                      /provider_calls.json   actual model status time and usage
                      /A2_<seed>_memory.json bounded memory
                      /summary.json          paired means uncertainty and limitations
output/provider_check.json                   provider connection checks
output/free_model_checks.json                availability sweep
output/figures/                              charts from saved results
output/submission/                           DOCX PPTX and final PDFs
```

Simulation outputs outside selfx are rejected. The original recorder now defaults to `selfx/output/testbed_results`.

## Current adaptive memory and fast control

`eval/run_simulation.py` now includes A4 in its normal five-controller run. Offline A4 calls `agent/adaptive_memory.py`; provider A4 calls `agent/fast_control.py`. The legacy A1/A2 branch remains reproducible. `eval/run_adaptive_benchmarks.py` runs the primary held-out eight-scenario suite. `eval/run_memory_sensitivity.py` runs the separate constructed mechanism diagnostic. `eval/run_latency_benchmark.py` measures all provider and local work for the three latency modes.

```mermaid
flowchart TD
    T[Generated NetFlow-style demand and current queues] --> E[Capacity-scaled context and action-local retrieval]
    E --> H{Healthy zero-queue state?}
    H -- Yes --> N[Explicit local no-op bypass]
    H -- No --> C{Exact validated cache hit?}
    C -- Yes --> R[Rebuild current flow parameters]
    C -- No --> M{Supported local memory decision?}
    M -- Yes --> R
    M -- No --> A[One compact API action choice]
    A --> R
    R --> V[Independent deterministic action validation]
    N --> V
    V --> O[Commit one simulated five-second outcome]
    O --> F[Local measured reflection and bounded episode update]
    F --> E
    O --> P[CSV and provider audit]
    P --> G[15 PNG and SVG graphs plus PDF atlas]
    P --> D[Editable DOCX and PPTX with native charts]
```

Current data lives in `output/benchmarks/v3`: primary CSV/traffic hashes, `traffic/simulated_netflow.csv`, `latency_gemini/`, preserved `latency_gemini_initial/`, `memory_sensitivity/`, `free_model_checks.json`, `figures/` and `chart_data.json`. The dashboard reads this version and the full portable run `output/experiments/venv_v3`. See [the current benchmark protocol](BENCHMARKS_V3.md) for evidence boundaries and actual results.
